﻿using System;
using LCE.StoreSystems.Common;
using LCE.StoreSystems.Common.Database;

namespace LCE.StoreSystems.Altametrics.LoadService
{
    public abstract class LoaderBase
    {
        #region Constructors...

        protected LoaderBase()
        {
        }

        protected LoaderBase(string dbConnectionString)
        {
            DbConnectionString = dbConnectionString;
        }

        protected LoaderBase(DataReader databaseReader)
        {
            DatabaseReader = databaseReader;
        }

        protected LoaderBase(string dbConnectionString, DataReader databaseReader)
        {
            DbConnectionString = dbConnectionString;
            DatabaseReader = databaseReader;
        }

        #endregion

        #region Properties...

        public string DbConnectionString { get; set; }

        public DataReader DatabaseReader { get; set; }

        #endregion

        #region Methods...

        public void DatabaseReaderConnectionClose()
        {
            try
            {
                if (DatabaseReader != null)
                {
                    DatabaseReader.SqlConnectionClose();
                }
            }

            catch (Exception ex)
            {
                throw new Exception("DatabaseReaderConnectionClose", ex);
            }
        }

        #endregion
    }
}
