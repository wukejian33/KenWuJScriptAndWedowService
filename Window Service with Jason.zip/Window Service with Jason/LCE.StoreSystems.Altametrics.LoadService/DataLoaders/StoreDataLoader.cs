﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common.Database;

namespace LCE.StoreSystems.Altametrics.LoadService
{
    [DataContract]
    public class StoreDataLoader : LoaderBase
    {
        #region Constructors...

        public StoreDataLoader()
        {
        }

        public StoreDataLoader(string dbConnectionString)
        {
            DbConnectionString = dbConnectionString;
        }

        public StoreDataLoader(DataReader databaseReader)
        {
            DatabaseReader = databaseReader;
        }

        public StoreDataLoader(string dbConnectionString, DataReader databaseReader)
        {
            DbConnectionString = dbConnectionString;
            DatabaseReader = databaseReader;
        }

        #endregion

        #region Methods...

        public StoreData StoreSaleLoad(out DateTime? currentBusinessDate)
        {
            return StoreSaleLoad(null, out currentBusinessDate); 
        }
        
        public StoreData StoreSaleLoad(DateTime? businessDate, out DateTime? currentBusinessDate)
        {
            SqlReader dataResult = null;
            currentBusinessDate = null;
            try
            {
                DatabaseReader = DatabaseReader ?? new DataReader(DbConnectionString);

                var sqlCommand = new SqlCommand {CommandType = CommandType.StoredProcedure, CommandText = "spAltametricsFeedStoreSale"};

                DataHelper.SqlCommandParameterDateTime2(sqlCommand, "@BusinessDate", businessDate);

                //Database connection will be opend (if closed or brooken) when creating SqlReader
                dataResult = DatabaseReader.SqlReaderOpen(sqlCommand);
                //-------------------------------------------------------------------------------------
                var storeData = new StoreData
                {
                    DailyNet = new StoreSaleDailyNet(),
                    DayParts = new StoreSaleDayParts(),
                    MenuMix = new StoreSaleMenuItems(),
                    Waste = new StoreWastes()
                };

                while (dataResult.ReadNextResult())
                {
                    while (dataResult.ReadRow())
                    {
                        var dataRow = dataResult.CollectionRow;

                        var dataRowType = dataRow.ColumnValueGet<string>("RowType");

                        switch (dataRowType)
                        {
                            case "BD":
                                currentBusinessDate = dataRow.ColumnValueGet<DateTime?>("BusinessDate");
                                break;

                            case "DT":
                                storeData.DailyNet = storeData.DailyNet ?? new StoreSaleDailyNet();
                                storeData.DailyNet.PropertiesReadFromDataRow(dataRow);
                                break;

                            case "DP":
                                storeData.DayParts = storeData.DayParts ?? new StoreSaleDayParts();
                                storeData.DayParts.AddUpdateFromDataRow<StoreSaleDayPart>(dataRow);
                                break;

                            case "MI":
                            case "MT":
                                storeData.MenuMix = storeData.MenuMix ?? new StoreSaleMenuItems();
                                storeData.MenuMix.AddUpdateFromDataRow<StoreSaleMenuItem>(dataRow);
                                break;

                            case "DW":
                                storeData.Waste = storeData.Waste ?? new StoreWastes();
                                storeData.Waste.AddUpdateFromDataRow<StoreWaste>(dataRow);
                                break;
                        }
                    }
                }
                //-------------------------------------------------------------------------------------
                return  storeData;
            }

            catch (Exception ex)
            {
                throw new Exception("StoreSaleLoad", ex);
            }

            finally
            {
                if (DatabaseReader != null)
                {
                    if (dataResult != null)
                    {
                        DatabaseReader.SqlReaderClose(dataResult);
                    }
                }
            }
        }
          
        public StoreData StoreEmployeeLoad()
        {
            SqlReader dataResult = null;

            try
            {
                DatabaseReader = DatabaseReader ?? new DataReader(DbConnectionString);

                var sqlCommand = new SqlCommand { CommandType = CommandType.StoredProcedure, CommandText = "spAltametricsFeedStoreEmployee" };

                //Database connection will be opend (if closed or brooken) when creating SqlReader
                dataResult = DatabaseReader.SqlReaderOpen(sqlCommand);
                //-------------------------------------------------------------------------------------
                var storeData = new StoreData();

                while (dataResult.ReadNextResult())
                {
                    while (dataResult.ReadRow())
                    {
                        var dataRow = dataResult.CollectionRow;
                                                                 
                        storeData.Employees = storeData.Employees ?? new StoreEmployees();
                        storeData.Employees.AddUpdateFromDataRow<StoreEmployee>(dataRow);
                    }
                }
                //-------------------------------------------------------------------------------------
                return storeData;

            }

            catch (Exception ex)
            {
                throw new Exception("StoreEmployeeLoad", ex);
            }

            finally
            {
                if (DatabaseReader != null)
                {
                    if (dataResult != null)
                    {
                        DatabaseReader.SqlReaderClose(dataResult);
                    }
                }
            }
        }
        
        #endregion
    }
}
