using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics
{
    [DataContract]
    public class StoreSaleDayPart : DataItemBase
    {
        #region Constructors...

        public StoreSaleDayPart ()
            : base()
        {
        }

        public StoreSaleDayPart (IEnumerable parent)
            : base(parent)
        {

        }

        #endregion

        #region Properties...

        [DataMember]
        public int DayPartId { get; set; }

        [DataMember]
        public double NetSalesAmount { get; set; }

        [DataMember]
        public double GrossSalesAmount { get; set; }

        [DataMember]
        public int TransactionCount { get; set; }

        [DataMember]
        public double TaxAmount { get; set; }
        
        #endregion

        #region Methods...

        public override void PropertiesReadFromDataRow(DataCollectionRow dataRow, List<string> collectionKeys)
        {
            try
            {
                CommonPropertiesReadFromDataRow(dataRow, collectionKeys);

                foreach (var columnName in dataRow.Columns)
                {
                    switch (columnName)
                    {
                        case "DayPartId":
                            DayPartId = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "NetSalesAmount":
                            NetSalesAmount = dataRow.ColumnValueGet<double>(columnName);
                            break;

                        case "GrossSalesAmount":
                            GrossSalesAmount = dataRow.ColumnValueGet<double>(columnName);
                            break;

                        case "TransactionCount":
                            TransactionCount = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "Tax":
                            TaxAmount = dataRow.ColumnValueGet<double>(columnName);
                            break;
                    }
                }

                Key = dataRow.CreateKey(collectionKeys);

                PropertiesUpdated = true;
            }

            catch (Exception ex)
            {
                throw new Exception("PropertiesReadFromDataRow", ex);
            }
        }

        #endregion
    }
}
