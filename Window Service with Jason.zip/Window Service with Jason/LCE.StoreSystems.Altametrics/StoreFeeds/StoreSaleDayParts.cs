using System;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics
{
    [CollectionDataContract]
    public class StoreSaleDayParts : DataCollectionBase<StoreSaleDayPart>
    {
        #region Constructors...

        public StoreSaleDayParts()
            : base()
        {
            ConstructKeys();
        }

        public StoreSaleDayParts(IEnumerable<StoreSaleDayPart> enumerable)
            : base(enumerable)
        {
            ConstructKeys();
        }
         

        private void ConstructKeys()
        {
            try
            {
                AddKey("DayPartId");
            }

            catch (Exception ex)
            {
                throw new Exception("ConstructKeys", ex);
            }
        }

        #endregion
    }
}
