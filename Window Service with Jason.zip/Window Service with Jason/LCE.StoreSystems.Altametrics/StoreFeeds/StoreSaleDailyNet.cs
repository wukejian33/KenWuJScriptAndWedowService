using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics
{
    [DataContract]
    public class StoreSaleDailyNet : DataItemBase
    {
        #region Constructors...

        public StoreSaleDailyNet()
            : base()
        {
        }
        
        #endregion

        #region Properties...

        [DataMember]
        public double NetSalesAmount { get; set; }

        [DataMember]
        public double GrossSalesAmount { get; set; }

        [DataMember]
        public int TransactionCount { get; set; }

        [DataMember]
        public double TaxAmount { get; set; }
        
        #endregion

        #region Methods...

        public void PropertiesReadFromDataRow(DataCollectionRow dataRow)
        {
            PropertiesReadFromDataRow(dataRow, null);
        }

        public override void PropertiesReadFromDataRow(DataCollectionRow dataRow, List<string> collectionKeys)
        {
            try
            {
                CommonPropertiesReadFromDataRow(dataRow, collectionKeys);

                foreach (var columnName in dataRow.Columns)
                {
                    switch (columnName)
                    {
                        case "NetSalesAmount":
                            NetSalesAmount = dataRow.ColumnValueGet<double>(columnName);
                            break;

                        case "GrossSalesAmount":
                            GrossSalesAmount = dataRow.ColumnValueGet<double>(columnName);
                            break;

                        case "TransactionCount":
                            TransactionCount = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "Tax":
                            TaxAmount = dataRow.ColumnValueGet<double>(columnName);
                            break;
                    }
                }

                if (collectionKeys != null)
                {
                    Key = dataRow.CreateKey(collectionKeys);
                }

                PropertiesUpdated = true;

            }

            catch (Exception ex)
            {
                throw new Exception("PropertiesReadFromDataRow", ex);
            }
        }

        #endregion
    }
}
