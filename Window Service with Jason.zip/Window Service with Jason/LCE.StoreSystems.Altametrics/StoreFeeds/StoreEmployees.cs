﻿using System.Threading.Tasks;
using System;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;


namespace LCE.StoreSystems.Altametrics
{
    [CollectionDataContract]
    public class StoreEmployees : DataCollectionBase<StoreEmployee>
    {
        #region Constructors...

        public StoreEmployees()
            : base()
        {
            ConstructKeys();
        }

        public StoreEmployees(IEnumerable<StoreEmployee> enumerable)
            : base(enumerable)
        {
            ConstructKeys();
        }


        private void ConstructKeys()
        {
            try
            {
                 AddKey("PayrollId");
            }

            catch (Exception ex)
            {
                throw new Exception("ConstructKeys", ex);
            }
        }

     
        #endregion
    }
}
