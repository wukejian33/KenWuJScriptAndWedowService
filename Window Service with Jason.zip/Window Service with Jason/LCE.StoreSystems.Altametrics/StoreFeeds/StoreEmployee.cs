﻿using System.Text;
using System.Threading.Tasks;
using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;


namespace LCE.StoreSystems.Altametrics
{
    [DataContract]
    public class StoreEmployee : DataItemBase
    {
        #region Constructors...

        public StoreEmployee()
            : base()
        {
        }

        public StoreEmployee(IEnumerable parent)
            : base(parent)
        {

        }

        #endregion

        #region Properties...

        [DataMember]
        public int PayrollId { get; set; }

        [DataMember]
        public string LastName { get; set; }

        [DataMember]
        public string FirstName { get; set; }

        [DataMember]
        public string MiddleName { get; set; } 

        [DataMember]
        public string HomeStoreId { get; set; } 

        [DataMember]
        public string SocialSecurityNumber { get; set; }

        [DataMember]
        public string StatusCode { get; set; } 

        [DataMember]
        public string SecurityCode { get; set; } 

        [DataMember]
        public string DateOfBirth { get; set; }   

        [DataMember]
        public string Address { get; set; }

        [DataMember]
        public string State { get; set; }

        [DataMember]
        public string City { get; set; }

        [DataMember]
        public string ZipCode { get; set; }

        [DataMember]
        public string PhoneNumber { get; set; }

        [DataMember]
        public string EmailAddress { get; set; }

        [DataMember]
        public string Gender { get; set; }

        [DataMember]
        public string MaritalState { get; set; }  

        [DataMember]
        public string Ethnic { get; set; } 

        [DataMember]
        public string EmergencyContactName { get; set; }

        [DataMember]
        public string EmergencyContactPhone { get; set; }

        [DataMember]
        public string EmergencyContactAddress { get; set; } 

        [DataMember]
        public int NumberDependents { get; set; }

        [DataMember]
        public string PartOrFullTime { get; set; }

        [DataMember]
        public string Disability { get; set; }

        [DataMember]
        public int JobCode { get; set; }

        [DataMember]
        public int IsPrimaryJobCode { get; set; } 

        [DataMember]
        public decimal PaidHourlyOrWeeklySalary { get; set; }

        [DataMember]
        public string JobEffectiveDate { get; set; }


        [DataMember]
        public string RateType { get; set; }

        #endregion

        #region Methods...

        public override void PropertiesReadFromDataRow(DataCollectionRow dataRow, List<string> collectionKeys)
        {
            string dateFormat = Helper.GetFormatOfDate(Helper.DateFormatType.MonthDayYearDash);

            try
            {
                CommonPropertiesReadFromDataRow(dataRow, collectionKeys);

                foreach (var columnName in dataRow.Columns)
                {
                    switch (columnName)
                    {
                        case "PayrollId":
                            PayrollId = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "LastName":
                            LastName = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "FirstName":
                            FirstName = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "MiddleName":
                            MiddleName = dataRow.ColumnValueGet<string>(columnName); ;
                            break;

                        case "HomeStoreId":
                            HomeStoreId = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "SocialSecurityNumber":
                            SocialSecurityNumber = dataRow.ColumnValueGet<string>(columnName).PadLeft(9, '*');
                            break;

                        case "StatusCode":
                            StatusCode = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "SecurityCode":
                            SecurityCode = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "DateOfBirth":
                            var dateOfBirthValue = dataRow.ColumnValueGet<string>(columnName);
                            DateOfBirth = Helper.IsDate(dateOfBirthValue) ? Convert.ToDateTime(dateOfBirthValue).ToString(dateFormat) : string.Empty;
                            break;

                        case "Address":
                            Address = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "State":
                            State = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "City":
                            if (string.IsNullOrEmpty(dataRow.ColumnValueGet<string>(columnName)))
                                City = "";
                            else
                                City = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "ZipCode":
                            ZipCode = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "PhoneNumber":
                            PhoneNumber = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "EmailAddress":
                            EmailAddress = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "Gender":
                            Gender = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "MaritalState":
                            MaritalState = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "Ethnic":
                            Ethnic = dataRow.ColumnValueGet<string>(columnName); ;
                            break;

                        case "EmergencyContactName":
                            EmergencyContactName = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "EmergencyContactPhone":

                            EmergencyContactPhone = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "EmergencyContactAddress":
                            EmergencyContactAddress = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "NumberDependents":
                            NumberDependents = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "PartOrFullTime":
                            PartOrFullTime = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "Disability":
                            Disability = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "JobCode":
                            JobCode = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "IsPrimaryJobCode":
                            IsPrimaryJobCode = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "PaidHourlyOrWeeklySalary":
                            PaidHourlyOrWeeklySalary = dataRow.ColumnValueGet<decimal>(columnName);
                            break;

                        case "JobEffectiveDate":
                            var jobEffectiveDateValue = dataRow.ColumnValueGet<string>(columnName);
                            JobEffectiveDate = Helper.IsDate(jobEffectiveDateValue) ? Convert.ToDateTime(jobEffectiveDateValue).ToString(dateFormat) : string.Empty;
                            break;

                        case "RateType":
                            RateType = dataRow.ColumnValueGet<string>(columnName);
                            break;
                    }
                }

                Key = dataRow.CreateKey(collectionKeys);

                PropertiesUpdated = true;
            }

            catch (Exception ex)
            {
                throw new Exception("PropertiesReadFromDataRow", ex);
            }
        }

        #endregion
    }
}
