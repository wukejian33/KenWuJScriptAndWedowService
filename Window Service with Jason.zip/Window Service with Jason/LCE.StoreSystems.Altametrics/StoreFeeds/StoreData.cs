using System;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace LCE.StoreSystems.Altametrics
{
    [DataContract]
    public class StoreData : MessageBaseStore
    {
        #region Properties...

        [DataMember]
        [JsonProperty(Order = 2, NullValueHandling = NullValueHandling.Ignore)]
        public StoreSaleDailyNet DailyNet { get; set; }

        [DataMember]
        [JsonProperty(Order = 2, NullValueHandling = NullValueHandling.Ignore)]
        public StoreSaleDayParts DayParts { get; set; }

        [DataMember]
        [JsonProperty(Order = 2, NullValueHandling = NullValueHandling.Ignore)]
        public StoreSaleMenuItems MenuMix { get; set; }

        [DataMember]
        [JsonProperty(Order = 2, NullValueHandling = NullValueHandling.Ignore)]
        public StoreEmployees Employees { get; set; }
        
        [DataMember]
        [JsonProperty(Order = 2, NullValueHandling = NullValueHandling.Ignore)]
        public StoreWastes Waste { get; set; }
        
        #endregion
    }
}
