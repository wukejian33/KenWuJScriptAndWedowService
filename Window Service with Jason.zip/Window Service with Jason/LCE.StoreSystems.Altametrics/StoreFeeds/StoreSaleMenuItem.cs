using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics
{
    [DataContract]
    public class StoreSaleMenuItem : DataItemBase
    {
        #region Constructors...

        public StoreSaleMenuItem()
            : base()
        {
        }

        public StoreSaleMenuItem(IEnumerable parent)
            : base(parent)
        {

        }

        #endregion

        #region Properties...

        [DataMember]
        public int ItemId { get; set; }

        [DataMember]
        public string ItemType { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public int Quantity { get; set; }

        [DataMember]
        public double Price { get; set; }

        [DataMember]
        public double TotalPrice { get; set; }

        [DataMember]
        public double Discount { get; set; }

        #endregion

        #region Methods...

        public override void PropertiesReadFromDataRow(DataCollectionRow dataRow, List<string> collectionKeys)
        {
            try
            {
                CommonPropertiesReadFromDataRow(dataRow, collectionKeys);

                foreach (var columnName in dataRow.Columns)
                {
                    switch (columnName)
                    {
                        case "ItemId":
                            ItemId = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "ItemType":
                            ItemType = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "Name":
                            Name = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "Quantity":
                            Quantity = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "Price":
                            Price = dataRow.ColumnValueGet<double>(columnName);
                            break;

                        case "TotalPrice":
                            TotalPrice = dataRow.ColumnValueGet<double>(columnName);
                            break;

                        case "Discount":
                            Discount = dataRow.ColumnValueGet<double>(columnName);
                            break;
                    }
                }

                Key = dataRow.CreateKey(collectionKeys);

                PropertiesUpdated = true;
            }

            catch (Exception ex)
            {
                throw new Exception("PropertiesReadFromDataRow", ex);
            }
        }

        #endregion
    }
}
