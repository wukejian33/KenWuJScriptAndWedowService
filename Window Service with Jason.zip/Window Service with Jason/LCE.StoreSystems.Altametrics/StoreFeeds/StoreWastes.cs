﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics
{
    [CollectionDataContract]
    public class StoreWastes : DataCollectionBase<StoreWaste>
    {
        #region Constructors...

        public StoreWastes()
            : base()
        {
            ConstructKeys();
        }

        public StoreWastes(IEnumerable<StoreWaste> enumerable)
            : base(enumerable)
        {
            ConstructKeys();
        }


        private void ConstructKeys()
        {
            try
            {
                AddKey("ItemId");
            }

            catch (Exception ex)
            {
                throw new Exception("ConstructKeys", ex);
            }
        }


        #endregion
    }
   
}
