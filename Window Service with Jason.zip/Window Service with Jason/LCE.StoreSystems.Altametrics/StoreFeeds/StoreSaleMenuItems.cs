using System;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics
{
    [CollectionDataContract]
    public class StoreSaleMenuItems : DataCollectionBase<StoreSaleMenuItem>
    {
        #region Constructors...

        public StoreSaleMenuItems()
            : base()
        {
            ConstructKeys();
        }

        public StoreSaleMenuItems(IEnumerable<StoreSaleMenuItem> enumerable)
            : base(enumerable)
        {
            ConstructKeys();
        }
         
        private void ConstructKeys()
        {
            try
            {
                AddKey("ItemId");
                AddKey("ItemType");
            }

            catch (Exception ex)
            {
                throw new Exception("ConstructKeys", ex);
            }
        }

        #endregion
    }
}
