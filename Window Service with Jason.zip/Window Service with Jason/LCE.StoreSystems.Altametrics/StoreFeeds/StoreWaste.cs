﻿using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.Serialization;
using LCE.StoreSystems.Common;
using System.Text;
using System.Threading.Tasks;

namespace LCE.StoreSystems.Altametrics
{
    [DataContract]
    public class StoreWaste : DataItemBase
    {
        #region Constructors...

        public StoreWaste()
            : base()
        {
        }

        public StoreWaste(IEnumerable parent)
            : base(parent)
        {

        }

        #endregion

        #region Properties...

        [DataMember]
        public int ItemId { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public decimal UnitCostAmount { get; set; }

        [DataMember]
        public int TotalQuantity { get; set; }

        [DataMember]
        public string  WasteUnit { get; set; }

        [DataMember]
        public string WasteReason { get; set; }

        #endregion

        #region Methods...

        public override void PropertiesReadFromDataRow(DataCollectionRow dataRow, List<string> collectionKeys)
        {
            try
            {
                CommonPropertiesReadFromDataRow(dataRow, collectionKeys);

                WasteUnit = "EA";
                WasteReason = "Expired Product";
                UnitCostAmount = 0;

                foreach (var columnName in dataRow.Columns)
                {
                    switch (columnName)
                    {
                        case "ItemId":
                            ItemId = dataRow.ColumnValueGet<int>(columnName);
                            break;

                        case "Name":
                            Name = dataRow.ColumnValueGet<string>(columnName);
                            break;

                        case "TotalQuantity":
                            TotalQuantity = dataRow.ColumnValueGet<int>(columnName);
                            break;

                    }
                }

                Key = dataRow.CreateKey(collectionKeys);

                PropertiesUpdated = true;
            }

            catch (Exception ex)
            {
                throw new Exception("PropertiesReadFromDataRow", ex);
            }
        }

        #endregion
    }

  
}
