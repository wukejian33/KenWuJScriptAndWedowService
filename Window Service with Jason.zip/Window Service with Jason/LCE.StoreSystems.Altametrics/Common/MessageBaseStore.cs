﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace LCE.StoreSystems.Altametrics
{
    [DataContract]
    public abstract class MessageBaseStore
    {
        #region Constructors...

        protected MessageBaseStore()
        {
        }

        #endregion

        #region Properties...

        [JsonProperty(Order = 1)]
        [DataMember(Name = "franchisenumber")]
        public int FranchiseNumber { get; set; }

        [JsonProperty(Order = 1)]
        [DataMember(Name = "corporatestoreid")]
        public int CorporateStoreId { get; set; }

        [JsonProperty(Order = 1)]
        [DataMember(Name = "storeid")]
        public int StoreId { get; set; }

        [JsonProperty(Order = 1)]
        [DataMember(Name = "businessdate")]
        public string BusinessDate { get; set; }
        
        [JsonProperty(Order = 1)]
        [DataMember(Name = "storedatetime")]
        public string StoreDateTime { get; set; }

        [JsonProperty(Order = 1)]
        [DataMember(Name = "storedatetimeutc")]
        public string StoreDateTimeUtc { get; set; }

        [JsonProperty(Order = 1)]
        [DataMember(Name = "returnstatus")]
        public bool ReturnStatus { get; set; }

        [JsonProperty(Order = 1)]
        [DataMember(Name = "returnmessage")]
        public string ReturnMessage { get; set; }

        #endregion
    }
}
