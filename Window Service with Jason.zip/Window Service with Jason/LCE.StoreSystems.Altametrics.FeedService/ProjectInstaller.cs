﻿using System.ComponentModel;
using System.Configuration.Install;
using System.ServiceProcess;

namespace LCE.StoreSystems.Altametrics.FeedService
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();

            FeedServiceInstaller.AfterInstall += ServiceInstaller_AfterInstall;  
        }

        private void ServiceInstaller_AfterInstall(object sender, InstallEventArgs e)
        {
            using (var sc = new ServiceController(FeedServiceInstaller.ServiceName))
            {
                sc.Start();
            }
        }
    }
}
