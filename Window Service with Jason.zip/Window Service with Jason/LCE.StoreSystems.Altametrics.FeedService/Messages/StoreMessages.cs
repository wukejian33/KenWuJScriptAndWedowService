﻿using System;
using System.Linq;
using LCE.ESBLib;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics.FeedService
{
    public class StoreMessages
    {
        public string MessageTypeStoreSalesFeed
        {
            get { return ServiceHelper.MessageTypeStoreSalesFeed; }
        }

        public string MessageTypeStoreEmployeeFeed
        {
            get { return ServiceHelper.MessageTypeStoreEmployeeFeed; }
        }

        public bool CallProcessStoreSalesFeed(string callingSource)
        {
            string returnMessage;
            var sent = false;

            try
            {
                var retValue = ServiceHelper.Initialize(out returnMessage, callingSource, false);
                //----------------------------------------------------------------------
                ServiceHelper.LogWriteNothing();
                ServiceHelper.LogWriteInformation(string.Format("Processing Message of Type: {0}", MessageTypeStoreSalesFeed));
                //----------------------------------------------------------------------
                if (!retValue)
                {
                    ServiceHelper.LogSavedWrite();
                    ServiceHelper.LogWriteError(returnMessage);

                    return false;
                }
                //----------------------------------------------------------------------
                var localStoreId = ServiceHelper.StoreId;
                var localFranchiseNumber = ServiceHelper.FranchiseNumber;
                var localCorporateStoreId = ServiceHelper.CorporateStoreId;
                //-------------------------------------------------------------------------
                DateTime? currentBusinessDate = null; 

                var storeSale = ServiceHelper.StoreSaleDataLoad(out returnMessage, out currentBusinessDate);

                if (storeSale == null)
                {
                    returnMessage = string.IsNullOrEmpty(returnMessage)
                        ? "Failed to Load Store Sales Data"
                        : string.Format("Failed to Load Store Sales Data, Error Message: {0}", returnMessage);

                    ServiceHelper.LogSavedWrite();
                    ServiceHelper.LogWriteError(returnMessage);
                    ServiceHelper.LogWriteError("Message Process Failed.");
                    return false;
                }
                //-------------------------------------------------------------------------
                storeSale.FranchiseNumber = localFranchiseNumber;
                storeSale.CorporateStoreId = localCorporateStoreId;
                storeSale.StoreId = localStoreId;
                storeSale.StoreDateTime = DateTime.Now.ToString(ServiceHelper.FormatDateTime);
                storeSale.StoreDateTimeUtc = DateTime.UtcNow.ToString(ServiceHelper.FormatDateTime);
                storeSale.BusinessDate=currentBusinessDate.HasValue ? currentBusinessDate.Value.ToString(ServiceHelper.FormatDateTime) : null;
                storeSale.ReturnStatus = true;

                var message = ServiceHelper.CreateMeesageJson(storeSale);

                if (string.IsNullOrEmpty(message))
                {
                    ServiceHelper.LogWriteError("Message Process Failed.");
                    return false;
                }

                if (ServiceHelper.AlwaysLogJsonMessage)
                {
                    ServiceHelper.LogWriteInformation(string.Format("Message Json:\r\n {0}", message));
                }
                //----------------------------------------------------------------------
                sent = ESBAppService.SendMessageToCorp(MessageTypeStoreSalesFeed, message);

                //SA: This is for debug only, in prod remove sent = true and uncomment the above line
                //sent = true;

                ServiceHelper.LogSavedWrite();

                if (!sent)
                {
                    ServiceHelper.LogWriteError("Message Process Failed, Call to ESBAppService.SendMessageToCorp(MessageTypeStoreSalesFeed, message) Failed.");
                    return false;
                }
                //----------------------------------------------------------------------
                ServiceHelper.SendFeedLastProcessDateTime = DateTime.Now;

                retValue = ServiceHelper.StoreSaleDataUpdateSendDateTime(out returnMessage);

                if (!retValue)
                {
                    returnMessage = string.IsNullOrEmpty(returnMessage)
                        ? "Failed to update database with the new Store Sales Send Date Time."
                        : string.Format("Failed to update database with the new Store Sales Send Date Time, Error Message: {0}", returnMessage);

                    ServiceHelper.LogWriteError(returnMessage);
                }
                else
                {
                    ServiceHelper.LogWriteInformation("Updated database and config file with the new Store Sales Send Date Time.");
                }
                //----------------------------------------------------------------------
                ServiceHelper.LogWriteInformation("Message Process Completed.");

                return true;
            }

            catch (Exception ex)
            {
                try
                {
                    returnMessage = Helper.CreateMessageFromException(ex);
                    ServiceHelper.LogSavedWrite();
                    ServiceHelper.LogWriteError(returnMessage);

                    return sent;
                }

                catch
                {
                    return sent;
                }
            }
        }

        public bool CallProcessStoreEmployeeFeed(string callingSource)
        {
            string returnMessage;
            var sent = false;

            try
            {
                var retValue = ServiceHelper.Initialize(out returnMessage, callingSource, false);
                //----------------------------------------------------------------------
                ServiceHelper.LogWriteNothing();
                ServiceHelper.LogWriteInformation(string.Format("Processing Message of Type (Employee Feed): {0}", MessageTypeStoreEmployeeFeed)); // 
                //----------------------------------------------------------------------
                if (!retValue)
                {
                    ServiceHelper.LogSavedWrite();
                    ServiceHelper.LogWriteError(returnMessage);

                    return false;
                }
                //----------------------------------------------------------------------
                var localStoreId = ServiceHelper.StoreId;
                var localFranchiseNumber = ServiceHelper.FranchiseNumber;
                var localCorporateStoreId = ServiceHelper.CorporateStoreId;
                //-------------------------------------------------------------------------
                var storeSale = ServiceHelper.StoreEmployeeDataLoad(out returnMessage);

                if (storeSale == null)
                {
                    returnMessage = string.IsNullOrEmpty(returnMessage)
                        ? "Failed to Load Store Employee  Data"
                        : string.Format("Failed to Load Store Employee Data, Error Message: {0}", returnMessage);

                    ServiceHelper.LogSavedWrite();
                    ServiceHelper.LogWriteError(returnMessage);
                    ServiceHelper.LogWriteError("Message Process Failed(Employee Feed).");
                    return false;
                }
                //-------------------------------------------------------------------------
                storeSale.FranchiseNumber = localFranchiseNumber;
                storeSale.CorporateStoreId = localCorporateStoreId;
                storeSale.StoreId = localStoreId;
                storeSale.StoreDateTime = DateTime.Now.ToString(ServiceHelper.FormatDateTime);
                storeSale.StoreDateTimeUtc = DateTime.UtcNow.ToString(ServiceHelper.FormatDateTime);
                storeSale.ReturnStatus = true;
                               
                var message = ServiceHelper.CreateMeesageJson(storeSale);

                if (string.IsNullOrEmpty(message))
                {
                    ServiceHelper.LogWriteError("Message Process Failed (Employee Feed).");
                    return false;
                }

                if (ServiceHelper.AlwaysLogJsonMessage)
                {
                    ServiceHelper.LogWriteInformation(string.Format("Message Json (Employee Feed):\r\n {0}", message));
                }
                //----------------------------------------------------------------------
                sent = ESBAppService.SendMessageToCorp(MessageTypeStoreEmployeeFeed, message);

                //SA: This is for debug only, in prod remove sent = true and uncomment the above line
                //sent = true;  // UnComment this

                ServiceHelper.LogSavedWrite();

                if (!sent)   
                {
                    ServiceHelper.LogWriteError("Message Process Failed (Employee Feed), Call to ESBAppService.SendMessageToCorp(MessageTypeStoreEmployeeFeed, message) Failed.");
                    return false;
                }
                //----------------------------------------------------------------------
                ServiceHelper.EmployeeFeedSendDateTime = DateTime.Now;

                retValue = ServiceHelper.StoreEmployeeDataUpdateSendDateTime(out returnMessage);

                if (!retValue)
                {
                    returnMessage = string.IsNullOrEmpty(returnMessage)
                        ? "Failed to update database with the new Store Employee Send Date Time."
                        : string.Format("Failed to update database with the new Store Employee Send Date Time, Error Message: {0}", returnMessage);

                    ServiceHelper.LogWriteError(returnMessage);
                }
                else
                {
                    ServiceHelper.LogWriteInformation("Updated database and config file with the new Store Employee Send Date Time.");
                }
                //----------------------------------------------------------------------
                ServiceHelper.LogWriteInformation("Message Process Completed (Employee Feed).");

                return true;
            }

            catch (Exception ex)
            {
                try
                {
                    returnMessage = Helper.CreateMessageFromException(ex);
                    ServiceHelper.LogSavedWrite();
                    ServiceHelper.LogWriteError(returnMessage);

                    return sent;
                }

                catch
                {
                    return sent;
                }
            }
        }

    }
}

