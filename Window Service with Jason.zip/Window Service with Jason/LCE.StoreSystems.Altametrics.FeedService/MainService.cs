﻿using System;
using System.ServiceProcess;
using System.Threading;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics.FeedService
{
    public partial class MainService : ServiceBase
    {
        #region Variables...

        private readonly object ObjectLock = new object();

        private const int ProcessorTimerIntervalSeconds = 60;

        private static int ProcessorTimerDatabaseCheckIntervalMinutes = 5;

        private static int ProcessorTimerDatabaseCheckIntervalCount = (60/ProcessorTimerIntervalSeconds)*ProcessorTimerDatabaseCheckIntervalMinutes;

        private static int ProcessorTimerDatabaseCheckIntervalCurrentCount = 0;

        private Timer ProcessorTimer;

        private bool Initialized { get; set; }

        private bool Processing { get; set; }
        

        #endregion

        #region Constructors...

        public MainService()
        {
            InitializeComponent();
        }

        #endregion

        #region Stop / Start Methods...

        protected override void OnStart(string[] args)
        {
            ServiceStart("OnStart", false, args);
        }

        protected override void OnStop()
        {
            ServiceStop("OnStop", false);
        }

        protected override void OnPause()
        {
            ServiceStop("OnPause", true);
        }

        protected override void OnContinue()
        {
            ServiceStart("OnStart", true);
        }

        protected override void OnShutdown()
        {
            ServiceStop("OnShutdown", false);
        }

        private void ServiceStop(string callingEvent, bool isPause)
        {
            try
            {
                ServiceHelper.LogWriteInformation(string.Format("{0} Service: {1}", (isPause ? "Pausing" : "Stoping"), ServiceName));

                if (ProcessorTimer != null)
                {
                    ProcessorTimer.Dispose();
                    ProcessorTimer = null;
                }
            }

            catch 
            {
                //ServiceHelper.ExceptionCheckAndWrite(callingEvent, ex);
            }

            finally
            {
                ServiceHelper.LogWriteLine();
                ServiceHelper.Terminate();
            }
        }

        private void ServiceStart(string callingEvent, bool isContinue)
        {
            ServiceStart(callingEvent, isContinue, new string[] {});
        }

        private void ServiceStart(string callingEvent, bool isContinue, string[] args)
        {
            try
            {
                string returnMessage;
                //------------------------------------------------------------------------------
                var retvalue = ServiceHelper.Initialize(out returnMessage, ServiceName, true);

                ServiceHelper.LogWriteInformation(string.Format("{0} Service: {1}", (isContinue ? "Continuing" : "Starting"), ServiceName));

                if (!retvalue)
                {
                    ServiceHelper.LogWriteError(string.Format("Failed to Start Service: {0}, Fail Message: {1}", ServiceName, returnMessage));
                }

                Initialized = retvalue;
                //------------------------------------------------------------------------------
                ProcessorTimerDatabaseCheckIntervalMinutes = (ServiceHelper.MessageDatabaseCheckIntervalMinutes > 0) ? ServiceHelper.MessageDatabaseCheckIntervalMinutes : 15;

                ProcessorTimerDatabaseCheckIntervalCount = (60/ProcessorTimerIntervalSeconds)*ProcessorTimerDatabaseCheckIntervalMinutes;

               // long interval = (retvalue ? ProcessorTimerIntervalSeconds : (5*60))*1000;   // Old Good
                long interval = 5 * 1000;

                ProcessorTimer = new Timer(OnTimer, null, interval, interval);
            }

            catch (Exception ex)
            {
                ServiceHelper.LogWriteException(callingEvent, ex);
            }
        }

        private void OnTimer(object stateInfo)
        {
            try
            {
                if (Processing) return;
                //-----------------------------------------------------------------------------------------
                if (!Initialized)
                {
                    string returnMessage;

                    Initialized = ServiceHelper.Initialize(out returnMessage, ServiceName, true);

                    if (!Initialized)
                    {
                        ServiceHelper.LogWriteError(string.Format("Failed to Initialize Service: {0}, Fail Message: {1}", ServiceName, returnMessage));
                        return;
                    }

                    var interval = ProcessorTimerIntervalSeconds*1000;

                    ProcessorTimer.Change(interval, interval);
                }
                //-----------------------------------------------------------------------------------------
                Processing = true;

                ServiceHelper.LogWriteHeartbeat();

                if (ProcessorTimerDatabaseCheckIntervalCurrentCount == 0 || ProcessorTimerDatabaseCheckIntervalCurrentCount >= ProcessorTimerDatabaseCheckIntervalCount)
                {
                    ProcessStoreSales();

                    ProcessStoreEmployeeFeed();

                    ProcessorTimerDatabaseCheckIntervalCurrentCount = 1;
                }
                else
                {
                    ProcessorTimerDatabaseCheckIntervalCurrentCount++;
                }

                ServiceHelper.LogSavedRemoveAll();
                //-----------------------------------------------------------------------------------------
                if (ServiceHelper.LogWriteCurrentFileShouldCreate)
                {
                    ServiceHelper.LogWriteInformation("Starting New Log File");
                }
                //-----------------------------------------------------------------------------------------
                Processing = false;
            }

            catch (Exception ex)
            {
                ServiceHelper.LogSavedWrite();
                ServiceHelper.LogWriteException("OnTimer", ex);
                Processing = false;
            }
        }

        #endregion

        #region Processing Methods...

        private void ProcessStoreSales()
        {
            try
            {
                bool sendFeed;

                var retValue = ServiceHelper.SendDateTimeValidate(out sendFeed);

                if (retValue && sendFeed)
                {
                    new StoreMessages().CallProcessStoreSalesFeed(ServiceName);
                }
            }

            catch (Exception ex)
            {
                ServiceHelper.LogSavedWrite();
                ServiceHelper.LogWriteException("ProcessStoreSales", ex);
            }
        }

        private void ProcessStoreEmployeeFeed()
        {
            try
            {
                bool sendFeed = false;
                string returnMessage;


                if (!ServiceHelper.LoadStorePreferences(out returnMessage, true))
                {
                    ServiceHelper.LogWriteError(returnMessage);
                    return;
                }
                      
                if (!ServiceHelper.EmployeeFeedRequestDateTime.HasValue)
                {
                    return;
                }

                sendFeed = (!ServiceHelper.EmployeeFeedSendDateTime.HasValue || ServiceHelper.EmployeeFeedSendDateTime.Value < ServiceHelper.EmployeeFeedRequestDateTime.Value);
                
                if (sendFeed)
                {
                    new StoreMessages().CallProcessStoreEmployeeFeed(ServiceName);
                }
            }

            catch (Exception ex)
            {
                ServiceHelper.LogSavedWrite();
                ServiceHelper.LogWriteException("ProcessStoreEmployeeFeed", ex);
            }
        }


        #endregion
    }
}


