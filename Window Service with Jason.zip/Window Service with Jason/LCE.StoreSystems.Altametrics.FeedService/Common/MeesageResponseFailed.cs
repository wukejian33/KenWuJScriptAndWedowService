﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace LCE.StoreSystems.Altametrics.FeedService
{
    [DataContract]
    public class MeesageResponseFailed
    {
        #region Properties...

        [DataMember]
        public int FranchiseNumber { get; set; }

        [DataMember]
        public int CorporateStoreId { get; set; }

        [DataMember]
        public int StoreId { get; set; }

        [DataMember]
        public string StoreDateTime { get; set; }

        [DataMember]
        public string StoreDateTimeUtc { get; set; }
        
        [DataMember]
        public bool ReturnStatus { get; set; }

        [DataMember]
        public string ReturnMessage { get; set; }

        #endregion
    }
}
