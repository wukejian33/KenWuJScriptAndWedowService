using System;
using System.Collections.Generic;
using System.Linq;
using LCE.StoreSystems.Altametrics.LoadService;
using LCE.StoreSystems.Common;
using LCE.StoreSystems.Common.Database;
using LCE.StoreSystems.StoreCommon;
using LCE.StoreSystems.StoreCommon.LoadService;
using Newtonsoft.Json;

namespace LCE.StoreSystems.Altametrics.FeedService
{
    public static partial class ServiceHelper
    {
        #region Variables...

        private static readonly object ObjectLock = new object();

        private const string RegKeyRoot = @"SOFTWARE\Custom Register Solutions\StreamPOS";

        private const string RegKeyValueDatabaseServer = "DatabaseServer";

        public const string MessageTypeStoreSalesFeed = "LCE.Message.Store.StoreSales.Feed";

        public const string MessageTypeStoreEmployeeFeed = "LCE.Message.Store.StoreEmployee.Feed";

        public const string ConfigKeyAlwaysLogJsonMessage = "AlwaysLogJsonMessage";

        public const string ConfigKeyCreateFormattedJsonMessage = "CreateFormattedJsonMessage";

        public const string ConfigKeyMessageDatabaseCheckIntervalMinutes = "MessageDatabaseCheckIntervalMinutes";

        public const string ConfigKeyLogFileFolder = "LogFileFolder";

        public const string ConfigKeyLogFileNamePrefix = "LogFileNamePrefix";

        public const string ConfigKeyLogFileMaxSizeInMB = "LogFileMaxSizeInMB";

        public const string ConfigKeyLogFilePurgeCycleDays = "LogFilePurgeCycleDays";

        public const string ConfigKeyDbConnectionString = "DbConnectionString";

        public const string PreferenceFeedSendDateTime = "AltametricsLastFeedSendDateTime";
         
        public const string PreferenceEmployeeFeedSendDateTime = "AltametricsLastEmployeeFeedSendDateTime";

        public const string PreferenceEmployeeFeedRequestDateTime = "AltametricsLastEmployeeFeedRequestDateTime";

        //-----------------------------------------------------------------------------------------
        //Feed send time
        //-----------------------------------------------------------------------------------------
        public const int SendFeedOnTimeIntervalCount = 96;

        public const string ConfigKeySendFeedOnStoreOpenPlusMinute = "SendFeedOnStoreOpenPlusMinute";

        public const string ConfigKeySendFeedOnStoreOpenMinusMinute = "SendFeedOnStoreOpenMinusMinute";

        public const string ConfigKeySendFeedOnStoreClosePlusMinute = "SendFeedOnStoreClosePlusMinute";

        public const string ConfigKeySendFeedOnStoreCloseMinusMinute = "SendFeedOnStoreCloseMinusMinute";

        public const string ConfigKeySendFeedOnTime = "SendFeedOnTime{0}";

        #endregion

        #region Properties...

        private static bool Initialized { get; set; }

        public static string FormatDate { get; private set; }

        public static string FormatTime { get; private set; }

        public static string FormatDateTime { get; private set; }

        public static int InitializeTryCount { get; private set; }

        public static DataReader DatabaseReader { get; set; }

        private static EventLog LogWriter { get; set; }

        public static StoreHours CurrentStoreHours { get; set; }

        public static DateTime? CurrentStoreHoursLastLoadDateTime { get; private set; }

        public static StorePreferences CurrentStorePreferences { get; set; }

        public static DateTime? CurrentStorePreferencesLastLoadDateTime { get; private set; }

        public static int MessageDatabaseCheckIntervalMinutes { get; private set; }

        public static bool AlwaysLogJsonMessage { get; private set; }

        public static bool CreateFormattedJsonMessage { get; private set; }

        public static string ServiceIpAddress { get; private set; }

        public static int FranchiseNumber { get; private set; }

        public static int CorporateStoreId { get; private set; }

        public static int StoreId { get; private set; }

        public static DateTime? SendFeedLastProcessDateTime { get;  set; }

        public static int SendFeedOnStoreOpenPlusMinute { get; private set; }

        public static int SendFeedOnStoreOpenMinusMinute { get; private set; }

        public static int SendFeedOnStoreClosePlusMinute { get; private set; }

        public static int SendFeedOnStoreCloseMinusMinute { get; private set; }

        public static Dictionary<int, DateTime> SendFeedTimes { get; private set; }

        public static DateTime? SendFeedDateTimeCheck { get; private  set; }

        public static DateTime? EmployeeFeedSendDateTime { get; set; }

        public static DateTime? EmployeeFeedRequestDateTime { get; private set; }

        #endregion

        #region Methods...

        public static string CreateMeesageResponseFaild(string returnMessage)
        {
            try
            {
                var faildMeesageReturn = new MeesageResponseFailed
                {
                    FranchiseNumber = FranchiseNumber,
                    CorporateStoreId = CorporateStoreId,
                    StoreId = StoreId,
                    StoreDateTime = DateTime.Now.ToString(FormatDateTime),
                    StoreDateTimeUtc = DateTime.UtcNow.ToString(FormatDateTime),
                    ReturnStatus = false,
                    ReturnMessage = returnMessage
                };

                return CreateMeesageJson(faildMeesageReturn);
            }

            catch (Exception ex)
            {
                LogWriter.WriteError(string.Format("Failed to create JSON, Exception Message: {0}", Helper.CreateMessageFromException(ex)));
                return string.Empty;
            }
        }

        public static string CreateMeesageJson(object messageObject)
        {
            try
            {
                return JsonConvert.SerializeObject(messageObject, CreateFormattedJsonMessage ? Formatting.Indented : Formatting.None);
            }

            catch (Exception ex)
            {
                LogWriter.WriteError(string.Format("Failed to create JSON, Exception Message: {0}", Helper.CreateMessageFromException(ex)));
                return string.Empty;
            }
        }

        public static StoreData StoreSaleDataLoad(out string returnMessage, out DateTime? currentBusinessDate)
        {
            StoreData storeData = null;
            returnMessage = string.Empty;
            currentBusinessDate = null;

            try
            {
                lock (ObjectLock)
                {
                    var dataLoader = new StoreDataLoader(DatabaseReader);

                    storeData = dataLoader.StoreSaleLoad(out currentBusinessDate);
                }

                return storeData;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to load Store Sales, Exception Message: {0}", Helper.CreateMessageFromException(ex));
                return storeData;
            }
        }

        public static StoreData StoreEmployeeDataLoad(out string returnMessage)
        {
            StoreData storeData = null;
            returnMessage = string.Empty;

            try
            {
                lock (ObjectLock)
                {
                    var dataLoader = new StoreDataLoader(DatabaseReader);

                    storeData = dataLoader.StoreEmployeeLoad();
                }

                return storeData;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to load Store Employee Data, Exception Message: {0}", Helper.CreateMessageFromException(ex));
                return storeData;
            }
        }

        public static bool StoreSaleDataUpdateSendDateTime(out string returnMessage)
        {
            returnMessage = string.Empty;
            var retValue = false;

            try
            {
                var value = (SendFeedLastProcessDateTime.HasValue ? SendFeedLastProcessDateTime.Value : DateTime.Now).ToString(FormatDateTime);

                lock (ObjectLock)
                {
                    var dataLoader = new CommonStoreDataLoader(DatabaseReader);

                    var preference = dataLoader.StorePreferenceSet(PreferenceFeedSendDateTime, string.Empty, value);

                    retValue = (preference != null);

                    if (!retValue)
                    {
                        returnMessage = string.Format("Could not Update Preference {0}", PreferenceFeedSendDateTime);
                    }
                }
                //--------------------------------------------------------------------------------------
                return retValue;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to Update Store Sales Send DateTime, Exception Message: {0}", Helper.CreateMessageFromException(ex));
                return retValue;
            }
        }

        public static bool StoreEmployeeDataUpdateSendDateTime(out string returnMessage)
        {
            returnMessage = string.Empty;
            var retValue = false;

            try
            {
                var value = (EmployeeFeedSendDateTime.HasValue? EmployeeFeedSendDateTime.Value : DateTime.Now).ToString(FormatDateTime);

                lock (ObjectLock)
                {
                    var dataLoader = new CommonStoreDataLoader(DatabaseReader);

                    var preference = dataLoader.StorePreferenceSet(PreferenceEmployeeFeedSendDateTime, string.Empty, value);

                    retValue = (preference != null);

                    if (!retValue)
                    {
                       returnMessage = string.Format("Could not Update Preference(PII) {0}", PreferenceEmployeeFeedSendDateTime);  
                    }
                }
                //--------------------------------------------------------------------------------------
                return retValue;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to Update Store Employee Send DateTime, Exception Message(PII): {0}", Helper.CreateMessageFromException(ex));
                return retValue;
            }
        }

        public static bool LoadStorePreferences(out string returnMessage)
        {
            return LoadStorePreferences(out returnMessage, false);
        }

        public static bool LoadStorePreferences(out string returnMessage, bool forceReload)
        {
            returnMessage = string.Empty;

            try
            {
                if (!forceReload)
                {
                    if (!CurrentStorePreferencesLastLoadDateTime.HasValue || CurrentStorePreferences == null || CurrentStorePreferences.Count == 0)
                    {
                        forceReload = true;
                    }
                    else if (CurrentStorePreferencesLastLoadDateTime.Value.AddHours(6) > DateTime.Now)
                    {
                        forceReload = true;
                    }
                }

                if (!forceReload)
                {
                    return true;
                }
                //------------------------------------------------------------------------------------
                lock (ObjectLock)
                {
                    var dataLoader = new CommonStoreDataLoader(DatabaseReader);

                    var preferences = new List<string>
                    {
                        "FranchiseNumber",
                        "StoreId",
                        "ServerIP",
                        PreferenceFeedSendDateTime,
                        PreferenceEmployeeFeedSendDateTime,
                        PreferenceEmployeeFeedRequestDateTime
                    };

                    CurrentStorePreferences = dataLoader.StorePreferencesGet(preferences);

                    if (CurrentStorePreferences == null || CurrentStorePreferences.Count == 0)
                    {
                        returnMessage = "Could not load store Preferences";
                    }
                }

                var retValue = (CurrentStorePreferences != null && CurrentStorePreferences.Count > 0);

                if (!retValue)
                {
                    return retValue;
                }
                //------------------------------------------------------------------------------------
                CurrentStorePreferencesLastLoadDateTime = DateTime.Now;

                var preference = CurrentStorePreferences.FirstOrDefault(p => Helper.StringCompare(p.Name, PreferenceFeedSendDateTime));

                if (preference != null && Helper.IsDate(preference.Value))
                {
                    SendFeedLastProcessDateTime = Helper.ConvertToDateTime(preference.Value);
                }
                //------------------------------------------------------------------------------------
                preference = CurrentStorePreferences.FirstOrDefault(p => Helper.StringCompare(p.Name, PreferenceEmployeeFeedSendDateTime));

                if (preference != null && Helper.IsDate(preference.Value))
                {
                    EmployeeFeedSendDateTime = Helper.ConvertToDateTime(preference.Value);
                }

                preference = CurrentStorePreferences.FirstOrDefault(p => Helper.StringCompare(p.Name, PreferenceEmployeeFeedRequestDateTime));

                if (preference != null && Helper.IsDate(preference.Value))
                {
                    EmployeeFeedRequestDateTime = Helper.ConvertToDateTime(preference.Value);
                }
                //------------------------------------------------------------------------------------
                return retValue;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to load Store Preferences, Exception Message: {0}", Helper.CreateMessageFromException(ex));
                return false;
            }
        }

        public static bool LoadStoreHours(out string returnMessage)
        {
            return LoadStoreHours(out returnMessage, false);
        }

        public static bool LoadStoreHours(out string returnMessage, bool forceReload)
        {
            returnMessage = string.Empty;

            try
            {
                if (!forceReload)
                {
                    if (!CurrentStoreHoursLastLoadDateTime.HasValue || CurrentStoreHours == null || CurrentStoreHours.Count == 0)
                    {
                        forceReload = true;
                    }
                    else if (CurrentStoreHoursLastLoadDateTime.Value.AddHours(6) > DateTime.Now)
                    {
                        forceReload = true;
                    }
                }

                if (!forceReload)
                {
                    return true;
                }

                lock (ObjectLock)
                {
                    var dataLoader = new CommonStoreDataLoader(DatabaseReader);

                    CurrentStoreHours = dataLoader.StoreHoursLoad();

                    if (CurrentStoreHours == null || CurrentStoreHours.Count == 0)
                    {
                        returnMessage = "Could not load Store Hours";
                    }
                }

                var retValue = (CurrentStoreHours != null && CurrentStoreHours.Count > 0);

                if (retValue)
                {
                    CurrentStoreHoursLastLoadDateTime = DateTime.Now;
                }

                return retValue;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to load Store Hours, Exception Message: {0}", Helper.CreateMessageFromException(ex));
                return false;
            }
        }

        public static bool SendDateTimeValidate(out bool sendFeed)
        {
            sendFeed = false;
            var returnMessage = string.Empty;

            try
            {
                var storeHours = CurrentStoreHours;
                var sendFeedTimes = SendFeedTimes;

                var sendFeedOnStoreOpenPlusMinute = SendFeedOnStoreOpenPlusMinute;
                var sendFeedOnStoreOpenMinusMinute = SendFeedOnStoreOpenMinusMinute;
                var sendFeedOnStoreClosePlusMinute = SendFeedOnStoreClosePlusMinute;
                var sendFeedOnStoreCloseMinusMinute = SendFeedOnStoreCloseMinusMinute;

                var storeHourCount = (storeHours == null) ? 0 : storeHours.Count;
                var sendFeedTimeCount = (sendFeedTimes == null) ? 0 : sendFeedTimes.Count;
                var minuteCount = sendFeedOnStoreOpenPlusMinute + sendFeedOnStoreOpenMinusMinute + sendFeedOnStoreClosePlusMinute + sendFeedOnStoreCloseMinusMinute;
                var nowDate = DateTime.Now.Date.ToString(FormatDate);
                //------------------------------------------------------------------------
                if (!SendFeedDateTimeCheck.HasValue || (SendFeedDateTimeCheck != DateTime.Now.Date))
                {
                    if (!LoadStoreHours(out returnMessage, true))
                    {
                        LogWriteError(string.Format("Failed to Load Store Hours, Fail Message: {0}", returnMessage));
                    }

                    if (sendFeedTimes != null && sendFeedTimeCount > 0)
                    {
                        for (var i = 1; i <= SendFeedOnTimeIntervalCount; i++)
                        {
                            if (!sendFeedTimes.ContainsKey(i))
                            {
                                continue;
                            }

                            var sendFeedTime = sendFeedTimes[i];

                            var timeValue = sendFeedTime.ToString(FormatTime);

                            var newDateTimeValue = string.Format("{0} {1}", nowDate, timeValue);

                            sendFeedTimes[i] = Convert.ToDateTime(newDateTimeValue);
                        }
                    }

                    storeHours = CurrentStoreHours;
                    storeHourCount = (storeHours == null) ? 0 : storeHours.Count;

                    sendFeedTimes = SendFeedTimes;
                    sendFeedTimeCount = (sendFeedTimes == null) ? 0 : sendFeedTimes.Count;

                    SendFeedDateTimeCheck = DateTime.Now.Date;
                }
                //------------------------------------------------------------------------
                if (sendFeedTimeCount == 0 && storeHourCount == 0)
                {
                    returnMessage = string.Format("COULD NOT DETERMINE The Time To Send The Feed, Please check Stor Hours and / or Config File");
                    LogWriteError(returnMessage);
                    return false;
                }

                if (sendFeedTimeCount == 0 && minuteCount == 0)
                {
                    returnMessage = string.Format("COULD NOT DETERMINE The Time To Send The Feed, Please check Stor Hours and / or Config File");
                    LogWriteError(returnMessage);
                    return false;
                }
                //---------------------------------------------------------------------
                if (!SendFeedLastProcessDateTime.HasValue)
                {
                    sendFeed = true;
                    return true;
                }
                //---------------------------------------------------------------------
                var lastSendTime = SendFeedLastProcessDateTime.Value;

                var nowSendFeedTimes = new List<DateTime>();

                if (sendFeedTimes != null && sendFeedTimeCount > 0)
                {
                    nowSendFeedTimes.AddRange(sendFeedTimes.Select(t => t.Value));
                }
                //---------------------------------------------------------------------
                if (storeHours != null && storeHourCount > 0 && minuteCount > 0)
                {
                    var todayStoreHours = storeHours.Where(h => h.DayOfWeekDate.HasValue && h.DayOfWeekDate.Value == DateTime.Now.Date).ToList();

                    foreach (var  todayStoreHour in  todayStoreHours)
                    {
                        if (sendFeedOnStoreOpenPlusMinute > 0 && todayStoreHour.StoreOpen.HasValue)
                        {
                            nowSendFeedTimes.Add(todayStoreHour.StoreOpen.Value.AddMinutes(sendFeedOnStoreOpenPlusMinute));
                        }

                        if (sendFeedOnStoreOpenMinusMinute > 0 && todayStoreHour.StoreOpen.HasValue)
                        {
                            nowSendFeedTimes.Add(todayStoreHour.StoreOpen.Value.AddMinutes(-1*sendFeedOnStoreOpenMinusMinute));
                        }

                        if (sendFeedOnStoreClosePlusMinute > 0 && todayStoreHour.StoreClose.HasValue)
                        {
                            nowSendFeedTimes.Add(todayStoreHour.StoreClose.Value.AddMinutes(sendFeedOnStoreClosePlusMinute));
                        }

                        if (sendFeedOnStoreCloseMinusMinute > 0 && todayStoreHour.StoreClose.HasValue)
                        {
                            nowSendFeedTimes.Add(todayStoreHour.StoreClose.Value.AddMinutes(-1*sendFeedOnStoreCloseMinusMinute));
                        }
                    }
                }
                //---------------------------------------------------------------------
                sendFeed = (nowSendFeedTimes.Where(t => (t >= lastSendTime && t <= DateTime.Now)).ToList().Count > 0);
                //---------------------------------------------------------------------
                return true;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to Validate Send Date Time, Exception Message: SendDateTimeValidate.{0}", Helper.CreateMessageFromException(ex));
                LogWriter.WriteError(returnMessage);
                return false;
            }
        }

        public static bool StoreIdValidate(int messageFranchiseNumber, int messageCorporateStoreId, int messageStoreId, out string returnMessage)
        {
            returnMessage = string.Empty;

            try
            {
                if (messageFranchiseNumber == 0 || messageCorporateStoreId == 0 || messageStoreId == 0)
                {
                    if (messageFranchiseNumber == 0)
                    {
                        returnMessage = string.Format("{0}{1}Invalid Franchise Number: {2}", returnMessage, (string.IsNullOrEmpty(returnMessage) ? string.Empty : ", "), messageFranchiseNumber);
                    }

                    if (messageCorporateStoreId == 0)
                    {
                        returnMessage = string.Format("{0}{1}Invalid Corporate Store Id: {2}", returnMessage, (string.IsNullOrEmpty(returnMessage) ? string.Empty : ", "), messageCorporateStoreId);
                    }

                    if (messageStoreId == 0)
                    {
                        returnMessage = string.Format("{0}{1}Invalid Store Id: {2}", returnMessage, (string.IsNullOrEmpty(returnMessage) ? string.Empty : ", "), messageStoreId);
                    }

                    LogWriter.SavedWrite();
                    LogWriter.WriteError(returnMessage);

                    return false;
                }
                //----------------------------------------------------------------------
                var localStoreId = StoreId;
                var localFranchiseNumber = FranchiseNumber;
                var localCorporateStoreId = CorporateStoreId;

                if (messageFranchiseNumber == localFranchiseNumber && messageCorporateStoreId == localCorporateStoreId && messageStoreId == localStoreId)
                {
                    return true;
                }
                //----------------------------------------------------------------------
                if (messageFranchiseNumber != localFranchiseNumber)
                {
                    returnMessage = string.Format("{0}{1}Franchise Number: {2} is not the same as Local Franchise Number: {3}", returnMessage, (string.IsNullOrEmpty(returnMessage) ? string.Empty : ", "), messageFranchiseNumber, localFranchiseNumber);
                }

                if (messageCorporateStoreId != localCorporateStoreId)
                {
                    returnMessage = string.Format("{0}{1}Corporate Store Id: {2} is not the same as Local Corporate Store Id: {3}", returnMessage, (string.IsNullOrEmpty(returnMessage) ? string.Empty : ", "), messageCorporateStoreId, localCorporateStoreId);
                }

                if (messageStoreId != localStoreId)
                {
                    returnMessage = string.Format("{0}{1}Store Id: {2} is not the same as Local Store Id: {3}", returnMessage, (string.IsNullOrEmpty(returnMessage) ? string.Empty : ", "), messageStoreId, localStoreId);
                }

                LogWriter.SavedWrite();
                LogWriter.WriteError(returnMessage);

                return false;
            }

            catch (Exception ex)
            {
                returnMessage = Helper.CreateMessageFromException(ex);
                LogWriter.SavedWrite();
                LogWriter.WriteError(returnMessage);
                return false;
            }
        }

        #endregion
    }
}