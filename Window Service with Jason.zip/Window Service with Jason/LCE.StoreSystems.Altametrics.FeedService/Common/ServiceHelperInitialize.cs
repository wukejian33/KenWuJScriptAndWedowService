using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using LCE.StoreSystems.Common;
using LCE.StoreSystems.Common.Database;

namespace LCE.StoreSystems.Altametrics.FeedService
{
    public static partial class ServiceHelper
    {
        #region Methods...

        public static bool Initialize(out string returnMessage, string callingSource, bool forceReloadPreferences)
        {
            returnMessage = string.Empty;

            try
            {
                if (Initialized)
                {
                    return true;
                }

                InitializeTryCount = InitializeTryCount + 1;

                CallingSource = callingSource;

                FormatDate = Helper.GetFormatOfDate(Helper.DateFormatType.MonthDayYearDash);

                FormatTime = Helper.GetFormatOfTime(Helper.DateTimeFormatType.TimeHours24);

                FormatDateTime = string.Format("{0} {1}", FormatDate, FormatTime);
                //---------------------------------------------------------------------
                InitializeLogWriter(out returnMessage);

                if (!InitializeCommon(out returnMessage))
                {
                    return false;
                }

                if (!InitializeDatabase(out returnMessage))
                {
                    return false;
                }
                //---------------------------------------------------------------------
                if (!InitializeStorePreferences(out returnMessage, forceReloadPreferences))
                {
                    return false;
                }
                //---------------------------------------------------------------------
                LoadStoreHours(out returnMessage);

                var storeHourCount = (CurrentStoreHours == null) ? 0 : CurrentStoreHours.Count;
                var sendFeedTimeCount = (SendFeedTimes == null) ? 0 : SendFeedTimes.Count;
                var minuteCount = SendFeedOnStoreOpenPlusMinute + SendFeedOnStoreOpenMinusMinute + SendFeedOnStoreClosePlusMinute + SendFeedOnStoreCloseMinusMinute;

                if (sendFeedTimeCount == 0 && storeHourCount == 0)
                {
                    returnMessage = string.Format("COULD NOT DETERMINE The Time To Send The Feed, Please check Stor Hours and / or Config File");
                    return false;
                }

                if (sendFeedTimeCount == 0 && minuteCount == 0)
                {
                    returnMessage = string.Format("COULD NOT DETERMINE The Time To Send The Feed, Please check Stor Hours and / or Config File");
                    return false;
                }
                //---------------------------------------------------------------------
                Initialized = true;
                //---------------------------------------------------------------------
                return true;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to initialize message helper, Exception Message: {0}", Helper.CreateMessageFromException(ex));
                return false;
            }
        }

        private static bool InitializeCommon(out string returnMessage)
        {
            returnMessage = string.Empty;

            try
            {
                string value;
                
                var nowDate = DateTime.Now.Date.ToString(FormatDate);
                //------------------------------------------------------------------------------
                var key = ConfigKeyAlwaysLogJsonMessage;
                AppSettingGet(key, out value, out returnMessage);
                AlwaysLogJsonMessage = (string.IsNullOrEmpty(value) || string.IsNullOrWhiteSpace(value)) || Helper.ConvertToBoolean(value);

                key = ConfigKeyCreateFormattedJsonMessage;
                AppSettingGet(key, out value, out returnMessage);
                CreateFormattedJsonMessage = Helper.ConvertToBoolean(value);

                key = ConfigKeyMessageDatabaseCheckIntervalMinutes;
                AppSettingGet(key, out value, out returnMessage);
                MessageDatabaseCheckIntervalMinutes = Helper.ConvertToInt(value, 0);

                if (MessageDatabaseCheckIntervalMinutes == 0)
                {
                    MessageDatabaseCheckIntervalMinutes = 15;
                }
                //------------------------------------------------------------------------------
                //Get Feed send times
                //------------------------------------------------------------------------------
                key = ConfigKeySendFeedOnStoreOpenPlusMinute;
                AppSettingGet(key, out value, out returnMessage);
                SendFeedOnStoreOpenPlusMinute = Helper.ConvertToInt(value);

                key = ConfigKeySendFeedOnStoreOpenMinusMinute;
                AppSettingGet(key, out value, out returnMessage);
                SendFeedOnStoreOpenMinusMinute = Helper.ConvertToInt(value);

                key = ConfigKeySendFeedOnStoreClosePlusMinute;
                AppSettingGet(key, out value, out returnMessage);
                SendFeedOnStoreClosePlusMinute = Helper.ConvertToInt(value);

                key = ConfigKeySendFeedOnStoreCloseMinusMinute;
                AppSettingGet(key, out value, out returnMessage);
                SendFeedOnStoreCloseMinusMinute = Helper.ConvertToInt(value);
                //------------------------------------------------------------------------------
                SendFeedTimes = SendFeedTimes ?? new Dictionary<int,DateTime>();
                SendFeedTimes.Clear();

                for (var i = 1; i <=  SendFeedOnTimeIntervalCount; i++)
                {
                    key = string.Format(ConfigKeySendFeedOnTime, i);
                    AppSettingGet(key, out value, out returnMessage);

                    value = string.IsNullOrEmpty(value) ? string.Empty : value.Trim();
                    value = string.IsNullOrEmpty(value) ? string.Empty : string.Format("{0} {1}", nowDate, value);
                    var sendFeedOnTime = Helper.IsDate(value) ? Helper.ConvertToDateTime(value) : null;

                    if (sendFeedOnTime.HasValue)
                    {
                        SendFeedTimes.Add(i, sendFeedOnTime.Value);
                    }
                }
                //------------------------------------------------------------------------------
                return true;
            }

            catch (Exception ex)
            {
                throw new Exception("InitializeCommon", ex);
            }
        }

        private static void InitializeLogWriter(out string returnMessage)
        {
            returnMessage = string.Empty;

            try
            {
                if (LogWriter != null) return;

                LogWriter = new EventLog();

                string value;

                var key = ConfigKeyLogFileFolder;
                string logFileFolder;
                AppSettingGet(key, out logFileFolder, out returnMessage);
                LogWriter.FilePath = logFileFolder;

                string logFileNamePrefix;
                key = ConfigKeyLogFileNamePrefix;
                AppSettingGet(key, out logFileNamePrefix, out returnMessage);
                LogWriter.FileNamePrefix = logFileNamePrefix;

                key = ConfigKeyLogFileMaxSizeInMB;
                AppSettingGet(key, out value, out returnMessage);

                var logFileMaxSizeInMb = Helper.ConvertToInt(value, -1);
                if (logFileMaxSizeInMb >= 0) LogWriter.FileMaxSizeInMb = logFileMaxSizeInMb;

                key = ConfigKeyLogFilePurgeCycleDays;
                AppSettingGet(key, out value, out returnMessage);
                var logFilePurgeCycleDays = Helper.ConvertToInt(value, -1);
                if (logFilePurgeCycleDays >= 0) LogWriter.FilePurgeCycleDays = logFilePurgeCycleDays;

                LogWriter.FilePurge();
            }

            catch (Exception ex)
            {
                throw new Exception("InitializeLogWriter", ex);
            }
        }

        private static bool InitializeDatabase(out string returnMessage)
        {
            returnMessage = string.Empty;

            try
            {
                if (DatabaseReader != null) return true;
                //---------------------------------------------------------------------
                string value;

                var key = ConfigKeyDbConnectionString;
                AppSettingGet(key, out value, out returnMessage);

                if (string.IsNullOrEmpty(value)) return false;

                var allParts = value.Split(';');
                //---------------------------------------------------------------------
                var passwordPart = allParts.FirstOrDefault(p => p.Trim().StartsWith("Password", StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(passwordPart))
                {
                    passwordPart = Regex.Replace(passwordPart, @"\s", "").Trim();
                    passwordPart = passwordPart.Substring(("Password=").Length);

                    passwordPart = string.Format("Password={0}", Helper.Decrypt(passwordPart));
                }
                //---------------------------------------------------------------------
                var serverPart = allParts.FirstOrDefault(p => p.Trim().StartsWith("Server", StringComparison.OrdinalIgnoreCase));

                if (!string.IsNullOrEmpty(serverPart))
                {
                    serverPart = Regex.Replace(serverPart, @"\s", "").Trim();
                    serverPart = serverPart.Substring(("Server=").Length);
                }

                var serverPartRegistry = GetDatabaseServerFromRegistry();

                serverPart = string.Format("Server={0}", string.IsNullOrEmpty(serverPartRegistry) ? serverPart : serverPartRegistry);
                //---------------------------------------------------------------------
                var dbConnectionString = string.Empty;

                foreach (var part in allParts)
                {
                    if (string.IsNullOrEmpty(part) || string.IsNullOrWhiteSpace(part)) continue;

                    var partStartsWith = part.Trim().StartsWith("Password", StringComparison.OrdinalIgnoreCase);
                    partStartsWith = (partStartsWith || part.Trim().StartsWith("Server", StringComparison.OrdinalIgnoreCase));

                    if (!partStartsWith)
                    {
                        dbConnectionString = string.Format("{0}{1};", dbConnectionString, part);
                    }
                }

                dbConnectionString = string.Format("{0}{1};{2};", dbConnectionString, passwordPart, serverPart);

                DatabaseReader = new DataReader(dbConnectionString);

                DatabaseReader.SqlConnectionOpen();
                //---------------------------------------------------------------------
                return true;
            }

            catch (Exception ex)
            {
                throw new Exception("InitializeDatabase", ex);
            }
        }

        private static bool InitializeStorePreferences(out string returnMessage, bool forceReload)  
        {
            returnMessage = string.Empty;

            try
            {
                if (!LoadStorePreferences(out returnMessage, forceReload))
                {
                    LogWriteError(string.Format("Failed to Load Store Preferences, Fail Message: {0}", returnMessage));
                    return false;
                }
                //---------------------------------------------------------------------
                var preferenceName = "StoreId";
                StoreId = GetStorePreferenceValueAsInt(preferenceName, true, true);

                var retvalue = (StoreId != 0);
                //---------------------------------------------------------------------
                preferenceName = "FranchiseNumber";
                var preferenceValue = GetStorePreferenceValue(preferenceName, true);
                var franchiseValues = string.IsNullOrEmpty(preferenceValue) ? new string[] {} : preferenceValue.Split('-');

                FranchiseNumber = (franchiseValues.Length != 2) ? 0 : Helper.ConvertToInt(franchiseValues[0], 0);

                CorporateStoreId = (franchiseValues.Length != 2) ? 0 : Helper.ConvertToInt(franchiseValues[1], 0);

                retvalue = (retvalue && FranchiseNumber != 0 && CorporateStoreId != 0);

                if (!string.IsNullOrEmpty(preferenceValue))
                {
                    if (FranchiseNumber == 0 || CorporateStoreId == 0)
                    {
                        returnMessage = string.Format("Invalid Preference Value {0} for Preference: {1}", preferenceValue, preferenceName);
                        LogWriter.SavedWrite();
                        LogWriter.WriteError(returnMessage);
                    }
                }
                //---------------------------------------------------------------------
                return retvalue;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to initialize message helper, Exception Message: {0}", Helper.CreateMessageFromException(ex));
                LogWriter.SavedWrite();
                LogWriter.WriteError(returnMessage);
                return false;
            }
        }

        private static int GetStorePreferenceValueAsInt(string preferenceName, bool onNullOrEmptyError, bool onZeroError, int defaultValue = 0)
        {
            var returnMessage = string.Empty;

            try
            {
                var preferenceValue = GetStorePreferenceValue(preferenceName, onNullOrEmptyError);

                if (string.IsNullOrEmpty(preferenceValue))
                {
                    return defaultValue;
                }

                var preferenceValueInt = Helper.ConvertToInt(preferenceValue, 0);

                if (preferenceValueInt == 0 && onZeroError)
                {
                    returnMessage = string.Format("Invalid Preference Value {0} for Preference: {1}", preferenceValue, preferenceName);
                    LogWriter.SavedWrite();
                    LogWriter.WriteError(returnMessage);
                }

                return (preferenceValueInt == 0) ? defaultValue : preferenceValueInt;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to Find Preference {0}, Exception Message: {1}", preferenceName, Helper.CreateMessageFromException(ex));
                LogWriter.SavedWrite();
                LogWriter.WriteError(returnMessage);
                return 0;
            }
        }

        private static string GetStorePreferenceValue(string preferenceName, bool onNullOrEmptyError)
        {
            var returnMessage = string.Empty;

            try
            {
                var preference = CurrentStorePreferences.FirstOrDefault(r => string.Compare(r.Name, preferenceName, StringComparison.OrdinalIgnoreCase) == 0);

                if (preference == null)
                {
                    returnMessage = string.Format("Failed to Find Preference {0}", preferenceName);
                    LogWriter.SavedWrite();
                    LogWriter.WriteError(returnMessage);
                }

                if (preference != null && string.IsNullOrEmpty(preference.Value) && onNullOrEmptyError)
                {
                    returnMessage = string.Format("Preference {0} has an Empty value", preferenceName);
                    LogWriter.SavedWrite();
                    LogWriter.WriteError(returnMessage);
                }

                return (preference == null) ? string.Empty : preference.Value;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to Find Preference {0}, Exception Message: {1}", preferenceName, Helper.CreateMessageFromException(ex));
                LogWriter.SavedWrite();
                LogWriter.WriteError(returnMessage);
                return string.Empty;
            }
        }


        private static string GetDatabaseServerFromRegistry()
        {
            var databaseServer = string.Empty;

            try
            {
                databaseServer = Helper.SystemRegistryReadLocalMachine<string>(RegKeyRoot, RegKeyValueDatabaseServer);

                if (string.IsNullOrEmpty(databaseServer))
                {
                    databaseServer = Helper.SystemRegistryReadCurrentUser<string>(RegKeyRoot, RegKeyValueDatabaseServer);
                }

                return databaseServer;
            }

            catch
            {
                return databaseServer;
            }
        }

        public static void Terminate()
        {
            try
            {
                if (DatabaseReader != null)
                {
                    DatabaseReader.SqlConnectionClose();
                }
            }

            catch
            {
                return;
            }
        }

        public static bool AppSettingGet(string key, out string value, out string returnMessage)
        {
            value = string.Empty;
            returnMessage = string.Empty;
            try
            {
                var retValue = ConfigurationManager.AppSettings[key];

                value = string.IsNullOrEmpty(retValue) ? string.Empty : retValue;

                return true;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to find Key {0} in configuration file, Exception Message: {1}", key, Helper.CreateMessageFromException(ex));
                return false;
            }
        }

        public static bool AppSettingSet(string key, string value, out string returnMessage)
        {
            returnMessage = string.Empty;
            try
            {
                var config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

                if (config.AppSettings.Settings.AllKeys.Contains(key))
                {
                    config.AppSettings.Settings[key].Value = value;
                }
                else
                {
                    config.AppSettings.Settings.Add(key, value);
                }

                config.Save(ConfigurationSaveMode.Modified);

                return true;
            }

            catch (Exception ex)
            {
                returnMessage = string.Format("Failed to Add / Update Key {0} in configuration file, Exception Message: {1}", key, Helper.CreateMessageFromException(ex));
                return false;
            }
        }

        internal static string GetDefaultFolder()
        {
            return Assembly.GetExecutingAssembly().Location;
        }

        #endregion
    }
}