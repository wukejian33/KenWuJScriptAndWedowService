using System;
using LCE.StoreSystems.Common;

namespace LCE.StoreSystems.Altametrics.FeedService
{
    public static partial class ServiceHelper
    {
        #region Write Log Methods...

        public static string CallingSource { get; set; }

        public static DateTime? LogWriteLastWriteDateTime
        {
            get { return (LogWriter == null) ? null : LogWriter.FileLastWriteDateTime; }
        }

        public static bool LogWriteCurrentFileShouldCreate
        {
            get
            {
                try
                {
                    if (LogWriter == null)
                    {
                        return false;
                    }

                    bool fileNameCurrentIsSet;

                    var fileExists = LogWriter.FileNameCurrentExists(out fileNameCurrentIsSet);

                    return fileNameCurrentIsSet && !fileExists;
                }

                catch
                {
                    return false;
                }
            }
        }

        public static void LogWriteLine()
        {
            LogWrite(Helper.EventLogMessageType.Line, string.Empty);
        }

        public static void LogWriteNothing()
        {
            LogWrite(Helper.EventLogMessageType.Nothing, string.Empty);
        }

        public static void LogWriteInformation(string message)
        {
            LogWrite(Helper.EventLogMessageType.Information, message);
        }

        public static void LogWriteWarning(string message)
        {
            LogWrite(Helper.EventLogMessageType.Warning, message);
        }

        public static void LogWriteError(string message)
        {
            LogWrite(Helper.EventLogMessageType.Error, message);
        }

        public static void LogWriteCritical(string message)
        {
            LogWrite(Helper.EventLogMessageType.Critical, message);
        }

        public static void LogWriteFailed(string message)
        {
            LogWrite(Helper.EventLogMessageType.Failed, message);
        }

        public static void LogWriteDelayed(string message)
        {
            LogWrite(Helper.EventLogMessageType.Delayed, message);
        }

        public static void LogWrite(Helper.EventLogMessageType messageType, string message)
        {
            LogWrite(messageType, message, string.Empty);
        }

        public static void LogWrite(Helper.EventLogMessageType messageType, string message, string callingEvent)
        {
            try
            {
                if (LogWriter != null)
                {
                    LogWriter.Write(messageType, message);
                }
                else if (messageType != Helper.EventLogMessageType.Nothing && messageType != Helper.EventLogMessageType.Line)
                {
                    Helper.SystemEventWriteMessage(CallingSource, callingEvent, message);
                }
            }
            catch
            {
                Helper.SystemEventWriteMessage(CallingSource, callingEvent, message);
            }
        }

        public static void LogWriteException(Exception exception)
        {
            LogWriteException(string.Empty, exception);
        }

        public static void LogWriteException(string callingEvent, Exception exception)
        {
            try
            {
                if (LogWriter != null)
                {
                    LogWriter.WriteException(exception);
                }
                else
                {
                    Helper.SystemEventWriteException(CallingSource, callingEvent, exception);
                }
            }
            catch
            {
                Helper.SystemEventWriteException(CallingSource, callingEvent, exception);
            }
        }


        public static void LogWriteHeartbeat()
        {
            try
            {
                if (LogWriter != null)
                {
                    LogWriter.WriteHeartbeat();
                }
            }
            catch
            {
                return;
            }
        }


        public static void LogSaveLine()
        {
            LogSave(Helper.EventLogMessageType.Line, string.Empty);
        }

        public static void LogSaveNothing()
        {
            LogSave(Helper.EventLogMessageType.Nothing, string.Empty);
        }

        public static void LogSaveInformation(string message)
        {
            LogSave(Helper.EventLogMessageType.Information, message);
        }

        public static void LogSaveWarning(string message)
        {
            LogSave(Helper.EventLogMessageType.Warning, message);
        }

        public static void LogSaveError(string message)
        {
            LogSave(Helper.EventLogMessageType.Error, message);
        }

        public static void LogSaveCritical(string message)
        {
            LogSave(Helper.EventLogMessageType.Critical, message);
        }

        public static void LogSaveFailed(string message)
        {
            LogSave(Helper.EventLogMessageType.Failed, message);
        }

        public static void LogSaveDelayed(string message)
        {
            LogSave(Helper.EventLogMessageType.Delayed, message);
        }

        public static void LogSaveException(Exception exception)
        {
            if (LogWriter != null)
            {
                LogWriter.SaveException(exception);
            }
        }

        public static void LogSave(Helper.EventLogMessageType messageType, string message)
        {
            if (LogWriter != null)
            {
                LogWriter.Save(messageType, message);
            }
        }

        public static void LogSavedWrite()
        {
            if (LogWriter != null)
            {
                LogWriter.SavedWrite();
            }
        }


        public static void LogSavedRemove(int removeLineCount)
        {
            if (LogWriter != null)
            {
                LogWriter.SavedRemove(removeLineCount);
            }
        }

        public static void LogSavedRemoveAll()
        {
            if (LogWriter != null)
            {
                LogWriter.SavedRemoveAll();
            }
        }

        #endregion
    }
}